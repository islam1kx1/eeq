package ru.zelmex.salahovcourseach.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import ru.zelmex.salahovcourseach.model.ModelLines;
import ru.zelmex.salahovcourseach.repository.ModelLinesDao;
import ru.zelmex.salahovcourseach.service.ModelLinesService;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

public class ClientController implements Initializable {

    private List<ModelLines> modelLines;
    private ObservableList<ModelLinesTableItem> creditsObservable;

    @FXML
    void addMode(ActionEvent event) {
        try {
            System.out.println("Начинаем загрузку FXML...");
            System.out.println("Путь: /ru/zelmex/salahovcourseach/add-edit-ModelLines-dialog.fxml");

            URL resource = getClass().getResource("/ru/zelmex/salahovcourseach/add-edit-ModelLines-dialog.fxml");
            System.out.println("URL ресурса: " + resource);

            FXMLLoader loader = new FXMLLoader(resource);
            System.out.println("Loader создан, загружаем...");

            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(clientsTable.getScene().getWindow());
            dialogStage.setMinWidth(400);
            dialogStage.setScene(new Scene(loader.load()));
            System.out.println("FXML загружен успешно!");

            dialogStage.setTitle("Добавить модель");
            AddEditModelLinesDialog controller = loader.getController();
            controller.setAddDialogStage(dialogStage);
            dialogStage.showAndWait();
            updateList();
        } catch (IOException e) {
            System.out.println("Ошибка открытия окна: " + e.getMessage());
            e.printStackTrace();  // <-- ЭТО ВАЖНО!
        }
    }

    @FXML
    void btnAddClient(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ru/zelmex/salahovcourseach/add-edit-ModelLines-dialog.fxml"));
            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(clientsTable.getScene().getWindow());
            dialogStage.setMinWidth(400);
            dialogStage.setScene(new Scene(loader.load()));
            dialogStage.setTitle("Добавить модель");
            AddEditModelLinesDialog controller = loader.getController();
            controller.setAddDialogStage(dialogStage);
            dialogStage.showAndWait();
            updateList();
        } catch (IOException e) {
            System.out.println("Ошибка открытия окна: " + e.getMessage());
        }
    }

    private void updateList() {
        try {
            modelLines = new ModelLinesService().findAll();
            creditsObservable.clear();
            if (modelLines != null) {
                for (ModelLines modelLinesItem : modelLines) {
                    creditsObservable.add(new ModelLinesTableItem(modelLinesItem));
                }
            }
            clientsTable.refresh();
        } catch (Exception e) {
            System.err.println("Ошибка в updateList():");
            e.printStackTrace();
        }
    }

    @FXML
    void btnDeleteClient(ActionEvent event) {
        ModelLinesTableItem currentItem = clientsTable.getSelectionModel().getSelectedItem();
        int currentItemId = clientsTable.getSelectionModel().getSelectedIndex();
        if (currentItemId != -1) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Подтверждение удаления");
            alert.setHeaderText("Удаление записи");
            alert.setContentText("Вы действительно хотите удалить \"" + currentItem.getName() + "\"?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                new ModelLinesService().delete(currentItem.getModelLines());
                clientsTable.getItems().remove(currentItemId);
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Предупреждение");
            alert.setContentText("Выберите запись в таблице для удаления");
            alert.showAndWait();
        }
    }

    @FXML
    void btnEditClient(ActionEvent event) {
        ModelLinesTableItem currentItem = clientsTable.getSelectionModel().getSelectedItem();
        int currentItemId = clientsTable.getSelectionModel().getSelectedIndex();
        if (currentItemId != -1) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/ru/zelmex/salahovcourseach/add-edit-ModelLines-dialog.fxml"));
                Stage dialogStage = new Stage();
                dialogStage.initModality(Modality.WINDOW_MODAL);
                dialogStage.initOwner(clientsTable.getScene().getWindow());
                dialogStage.setMinWidth(400);
                dialogStage.setScene(new Scene(loader.load()));
                dialogStage.setTitle("Редактировать модель");
                AddEditModelLinesDialog controller = loader.getController();
                controller.setEditDialogStage(dialogStage, currentItem.getModelLines());
                dialogStage.showAndWait();
                updateList();
            } catch (IOException e) {
                System.out.println("Ошибка открытия окна: " + e.getMessage());
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Предупреждение");
            alert.setContentText("Выберите запись в таблице для редактирования");
            alert.showAndWait();
        }
    }

    @FXML
    void btnOff(ActionEvent event) {
        Stage stage = (Stage) clientsTable.getScene().getWindow();
        stage.close();
    }

    @FXML
    void btnUpdateClients(ActionEvent event) {
        updateList();
    }

    // НОВЫЕ КОЛОНКИ (вместо старых)
    @FXML
    private TableColumn<ModelLinesTableItem, Integer> modelIdColumn;
    @FXML
    private TableColumn<ModelLinesTableItem, String> nameColumn;
    @FXML
    private TableColumn<ModelLinesTableItem, String> typeColumn;
    @FXML
    private TableColumn<ModelLinesTableItem, String> specificationsColumn;
    @FXML
    private TableColumn<ModelLinesTableItem, Double> priceColumn;
    @FXML
    private TableView<ModelLinesTableItem> clientsTable;

    private final ModelLinesDao modelLinesDao = new ModelLinesDao();


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        modelIdColumn.setCellValueFactory(new PropertyValueFactory<>("modelId"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        specificationsColumn.setCellValueFactory(new PropertyValueFactory<>("specifications"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        // ИНИЦИАЛИЗАЦИЯ СПИСКА (ЭТО ГЛАВНОЕ!)
        creditsObservable = FXCollections.observableArrayList();
        clientsTable.setItems(creditsObservable);

        updateList();
    }

    @FXML
    void onClickMotorcycles(ActionEvent event) {
        updateList();
    }

    @FXML
    void onTypesClick(ActionEvent event) {
        // TODO: открыть окно с типами мотоциклов
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Информация");
        alert.setContentText("Раздел в разработке");
        alert.showAndWait();
    }

    @FXML
    void powerOff(ActionEvent event) {
        Stage stage = (Stage) clientsTable.getScene().getWindow();
        stage.close();
    }

    @FXML
    void addModel(ActionEvent event) {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ru/zelmex/salahovcourseach/add-edit-ModelLines-dialog.fxml"));
            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(clientsTable.getScene().getWindow());
            dialogStage.setMinWidth(400);
            dialogStage.setScene(new Scene(loader.load()));
            dialogStage.setTitle("Добавить модель");
            AddEditModelLinesDialog controller = loader.getController();
            controller.setAddDialogStage(dialogStage);
            dialogStage.showAndWait();
            updateList();
        } catch (IOException e) {
            System.out.println("Ошибка открытия окна: " + e.getMessage());
        }
    }

    @FXML
    void editModel(ActionEvent event) {
        ModelLinesTableItem currentItem = clientsTable.getSelectionModel().getSelectedItem();
        int currentItemId = clientsTable.getSelectionModel().getSelectedIndex();
        if (currentItemId != -1) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/ru/zelmex/salahovcourseach/add-edit-ModelLines-dialog.fxml"));
                Stage dialogStage = new Stage();
                dialogStage.initModality(Modality.WINDOW_MODAL);
                dialogStage.initOwner(clientsTable.getScene().getWindow());
                dialogStage.setMinWidth(400);
                dialogStage.setScene(new Scene(loader.load()));
                dialogStage.setTitle("Редактировать модель");
                AddEditModelLinesDialog controller = loader.getController();
                controller.setEditDialogStage(dialogStage, currentItem.getModelLines());
                dialogStage.showAndWait();
                updateList();
            } catch (IOException e) {
                System.out.println("Ошибка открытия окна: " + e.getMessage());
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Предупреждение");
            alert.setContentText("Выберите запись в таблице для редактирования");
            alert.showAndWait();
        }
    }

    @FXML
    void deleteModel(ActionEvent event) {
        ModelLinesTableItem currentItem = clientsTable.getSelectionModel().getSelectedItem();
        int currentItemId = clientsTable.getSelectionModel().getSelectedIndex();
        if (currentItemId != -1) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Подтверждение удаления");
            alert.setHeaderText("Удаление записи");
            alert.setContentText("Вы действительно хотите удалить \"" + currentItem.getName() + "\"?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                new ModelLinesService().delete(currentItem.getModelLines());
                clientsTable.getItems().remove(currentItemId);
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Предупреждение");
            alert.setContentText("Выберите запись в таблице для удаления");
            alert.showAndWait();
        }
    }

    @FXML
    void updateModels(ActionEvent event) {
        updateList();
    }
}