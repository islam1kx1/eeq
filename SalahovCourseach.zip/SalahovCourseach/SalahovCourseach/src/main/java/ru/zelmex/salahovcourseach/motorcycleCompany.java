package ru.zelmex.salahovcourseach;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;

public class motorcycleCompany extends Application {
    public static Stage primaryStage;
    public static Scene mainScene;

    @Override
    public void start(Stage stage) throws IOException {
        primaryStage = stage;
        mainScene = createScene("ModelLines-view.fxml");  // имя вашего FXML файла

        primaryStage.setMinWidth(1200);
        primaryStage.setMinHeight(675);
        primaryStage.setTitle("Мотоциклы - Каталог моделей");
        mainScene.getStylesheets().add("base-styles.css");
        primaryStage.setScene(mainScene);
        primaryStage.show();
    }

    private Scene createScene(String name) throws IOException {
        URL resource = getClass().getResource("/ru/zelmex/salahovcourseach/" + name);
        if (resource == null) {
            System.err.println("FXML файл не найден: " + name);
            throw new IOException("Resource not found: " + name);
        }
        FXMLLoader fxmlLoader = new FXMLLoader(resource);
        return new Scene(fxmlLoader.load());
    }

    public static void main(String[] args) {
        launch();
    }
}